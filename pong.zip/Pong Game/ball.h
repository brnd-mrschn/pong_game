#ifndef BALL_H
#define BALL_H

#include <QGraphicsEllipseItem>
#include <QVector2D>

class Ball : public QGraphicsEllipseItem
{
public:
    Ball(qreal x, qreal y, qreal width, qreal height, QGraphicsItem *parent = nullptr);

    void advance(int phase) override;
    void startMovement();
    void resetPosition();

    // Métodos para obter e definir a velocidade
    qreal getSpeed() const { return speed; }
    void setSpeed(qreal newSpeed) { speed = newSpeed; }

private:
    QVector2D position;
    QVector2D velocity;
    QVector2D acceleration;
    int collisionBlock = 0;
    qreal speed;  // Variável de instância para a velocidade
    bool edge_flag;
    void handleCollisions();
};

#endif // BALL_H
